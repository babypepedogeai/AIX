import React from "react";
import { Rocket, Infinity, MessageCircle, Copy } from "lucide-react";
import Image from "next/image";

export default function HomePage() {
  return (
    <div style={{ backgroundColor: 'black', color: 'white', minHeight: '100vh', padding: '2rem', textAlign: 'center' }}>
      <Image src="/aixxx22.png" alt="Banner" width={600} height={300} />
      <h1 style={{ fontSize: '3rem', fontWeight: 'bold', marginTop: '1rem' }}>
        ai.<span style={{ color: '#ec4899' }}>x</span><span style={{ color: '#facc15' }}>∞</span>
      </h1>
      <p style={{ fontSize: '1.5rem', maxWidth: '600px', margin: '1rem auto', color: '#ccc' }}>
        Memes Meet AI. Doge Drives. Pepe Commands. ∞ Powered.
      </p>
      <div style={{ marginTop: '1rem' }}>
        <a href="https://pump.fun/BDZvYmp4pC9ssxQsERyjhqqzcx3YkK1uPAvNdaNypump" target="_blank" rel="noopener noreferrer" style={{ marginRight: '1rem', backgroundColor: '#ec4899', color: 'white', padding: '0.5rem 1rem', borderRadius: '8px', textDecoration: 'none' }}>Buy $AIX∞</a>
        <a href="#" style={{ border: '1px solid white', padding: '0.5rem 1rem', borderRadius: '8px', textDecoration: 'none', color: 'white' }}>View Tokenomics</a>
      </div>
    </div>
  );
}